import { useState } from "react";
import "./assets/css/App.css";
import HomePage from "./pages/Home";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SinglePage from "./pages/singlePost";
import SingleProduct from "./pages/singleProduct";
import Login from "./pages/login";
import Signup from "./pages/Signup";
import Profile from "./pages/profile";
import Error from "./pages/404";
import Dashboard from "./pages/dashboard/dashboard";
import CreateBlog from "./pages/dashboard/Content/IndexBlog";
import Create from "./pages/dashboard/Content/Create";
import Edit from "./pages/dashboard/Content/Edit";
import ProductIndex from "./pages/dashboard/shop/Index";
import EditProduct from "./pages/dashboard/shop/Edit";
import CreateProduct from "./pages/dashboard/shop/Create";
import UsersIndex from "./pages/dashboard/admin/Index";

function App() {
  const [isLoading, setLoading] = useState(false);

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />}></Route>
          <Route path="/singlePage/:id" element={<SinglePage />} />
          <Route path="/singleProduct/:id" element={<SingleProduct />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/Content/createblog" element={<CreateBlog />} />
          <Route path="/Content/Create" element={<Create />} />
          <Route path="/Content/edit/:id" element={<Edit />} />
          <Route path="/shop/index" element={<ProductIndex />} />
          <Route path="/shop/edit/:id" element={<EditProduct />} />
          <Route path="/shop/create" element={<CreateProduct />} />
          <Route path="/admin/index" element={<UsersIndex />} />
          <Route path="*" element={<Error />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
