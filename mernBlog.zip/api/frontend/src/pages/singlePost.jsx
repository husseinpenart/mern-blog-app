import React, { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import axios from "axios";
import moment from "moment";

const SinglePage = () => {
  const singleId = useLocation().pathname.split("/")[2];
  const [single, setSingle] = useState();
  useEffect(() => {
    const fetchBlogs = async () => {
      const results = await axios.get(
        "http://localhost:4000/blogs/singlePost/" + singleId
      );
      setSingle(results.data);
      console.log(results.data);
    };
    fetchBlogs();
  }, []);

  return (
    <>
      <div className="post-container">
        {single ? (
          <div>
            <br />
            <br />
            <br />
            <img
              src={single.image}
              alt=""
              style={{ margin: "0 auto", display: "block", borderRadius: 35 }}
            />
            <br />
            <br />
            <h1 style={{ color: "white", textAlign: "center" }}>
              {single.title}
            </h1>
         <br />
         <br />
            <div style={{position:'relative' , display:'flex' ,flexWrap:'wrap'}}>
         
           <p style={{ color: "white", textAlign:'center',padding:10 }}>
             Category:   <span style={{background:'blue', padding:5 , borderRadius:10}}>{single.category}</span>
              </p>
              <p style={{ color: "white", textAlign:'center',padding:10 }}>
             Writer:   <span style={{background:'green', padding:5 , borderRadius:10 }}>{single.writer}</span>
              </p>
              <p style={{ color: "white", textAlign:'center',padding:10 }}>
             Date:   <span style={{background:'#65c4ff', padding:5 , borderRadius:10 }}>{moment(single.createdAt).format('MMMM Do YYYY')}</span>
              </p>
        

            </div>
           
            <br />
            <br />
            <p style={{margin:'0 auto',display:'block' , width:'50%' }}>
                <span  style={{color:'white', lineHeight:3 }}>{single.content}</span>
            </p>


          </div>
        ) : null}
      </div>
    </>
  );
};

export default SinglePage;
