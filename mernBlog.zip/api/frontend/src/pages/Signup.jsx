import React, { useState, useEffect } from "react";
import axios from "axios";
import {Link} from 'react-router-dom'
import { ToastContainer, toast } from "react-toastify";

const Signup = () => {
  const [name, setName] = useState();
  const [username, setUsername] = useState();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [register, setRegister] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    const configuration = {
      method: "post",
      url: "http://localhost:4000/admins/createAdmin",
      data: {
        name,
        username,
        email,
        password,
      },
    };
    axios(configuration)
      .then((result) => {
        window.location.href = '/login'
        setRegister(true);
      })
      .catch((error) => {
        error = new Error();
      });
  };
  
  const notify = () =>
    toast("🦄 you are Registered  successfully", {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  return (
    <>
      <br />
      <br />
      <h1 style={{ textAlign: "center", color: "white" }}>Register</h1>
      <div className="signup-page">
        <div className="form-register">
          <form onSubmit={(e) => handleSubmit(e)}>
            <input
              type="text"
              value={name}
              name="name"
              className="sign-form"
              onChange={(e) => setName(e.target.value)}
              placeholder="name"
            />
            <input
              type="text"
              value={username}
              name="username"
              className="sign-form"
              onChange={(e) => setUsername(e.target.value)}
              placeholder="username"
            />
            <input
              type="email"
              value={email}
              name="email"
              className="sign-form"
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email"
            />
            <input
              type="password"
              value={password}
              name="password"
              className="sign-form"
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password"
            />
            <br />
            <button
              className="submit"
              type="submit"
              onClick={(e) => handleSubmit(e)}
            >
              Register
            </button>
            <ToastContainer />
            {register ? (
              notify()
            ) : (
              <p style={{color:'yellow'}}>have an Account ?<Link to="/login" style={{color:'white'}}> Login </Link></p>
            )}
            
          </form>
        </div>
      </div>
    </>
  );
};
export default Signup;
