import React from "react";
import NavBar from "../components/navbar";
import Hero from "../components/Hero";
import Blog from "../components/Blog";
import Products from "../components/Products";
const HomePage = ()=>{
   return(
       <>
       <NavBar />
       <Hero />
       <Blog />
       <Products />
       </>
   )
}
export default HomePage