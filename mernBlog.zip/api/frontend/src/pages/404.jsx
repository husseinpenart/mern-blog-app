import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ReactAudioPlayer from "react-audio-player";
import DeadSound from "../assets/sound/background.mp3";

const Error = () => {
  const ref = React.useRef(false);
  const dangerText = React.useRef(false);
  const hideAdviceMessage = React.useRef(false);
  const bloodHand = React.useRef(false)
  const finalText = React.useRef(false)
  useEffect(() => {
    const hideMessage = setTimeout(() => {
        hideAdviceMessage.current.style.display = "none";
      }, 3000);
    const dangerMessage = setTimeout(() => {
      dangerText.current.style.display = "block";
    }, 3000);

    const showZombie = setTimeout(() => {
        dangerText.current.style.display = "none";
      ref.current.style.display = "block";
      finalText.current.style.display = "block";

    }, 13000);
    const showDeadHand = setTimeout(()=>{
        bloodHand.current.style.display = "block";
     
    } , 2000)
    const endofLine = setTimeout(() => {
        window.location.href = '/'
    }, 17000);
    return () => clearTimeout(showZombie, dangerMessage, hideMessage,showDeadHand,endofLine);
  }, []);
  return (
    <>

<ReactAudioPlayer
  src={DeadSound}
  autoPlay={true}
  loop={true}
  
/>

      <div style={{ margin: "0 auto", display: "block" }}>
        <h1
          style={{
            fontSize: 135,
            color: "red",
            textAlign: "center",
            marginTop: 30,
            fontFamily: "zombie",
          }}
        >
          404
        </h1>
        <br />
        
        <h3
          style={{
            fontSize: 55,
            color: "red",
            textAlign: "center",
            marginTop: "30vh",
            fontFamily: "zombie",
          }}
          ref={hideAdviceMessage}
        >
          This Page is not Safe Please Get Back
        </h3>
        <br />
        <h3
          style={{
            fontSize: 55,
            color: "red",
            textAlign: "center",
            fontFamily: "zombie",
            display: "none",
            marginTop: "30vh",
          }}
          className="text-focus-in"
          ref={dangerText}
        >
          Please This Page is dangers Don't Stay
        </h3>
        <h3
          style={{
            fontSize: 55,
            color: "red",
            textAlign: "center",
            fontFamily: "zombie",
            display: "none",
            marginTop: "15vh",
            position:'relative',
            zIndex:1000
          }}
          className="text-focus-in"
          ref={finalText}
        >
         I warned You 
        </h3>
        <br />
        <img
          src="https://clipart.info/images/ccovers/1634921221hand-blood-png-image-2.png"
          alt=""
          className="puff-in-center"
          ref={bloodHand}
        />
        <img
          src="https://www.pngmart.com/files/22/Zombie-PNG-HD.png"
          ref={ref}
          alt=""
          style={{
            width: 500,
            margin: "0 auto",
            height: "40vh",
            display: "none",
            position: "relative",
            zIndex: 100,
            transition: "linear",
          }}
          className="flicker-in-1"
        />
        <br />
        <button
          style={{
            width: 300,
            height: 55,
            background: "red",
            fontFamily: "zombie",
            fontSize: 45,
            border: "none",
            margin: "0 auto",
            display: "block",
          }}
        >
          <Link to="/" style={{ textDecoration: "none", color: "white" }}>
            {" "}
            Back to Home
          </Link>
        </button>
      </div>
    </>
  );
};

export default Error;
