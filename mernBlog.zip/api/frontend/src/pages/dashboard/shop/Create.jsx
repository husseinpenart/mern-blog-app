import React, { useEffect, useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import Cookies from "universal-cookie";
import { useNavigate  } from "react-router-dom";

const CreateProduct = () => {
  const [title, setTitle] = useState();
  const [content, setContent] = useState();
  const [category, setCategory] = useState();
  const [inventory, setInventory] = useState();
  const [discount, setDiscount] = useState();
  const [image, setImage] = useState();
  const [previewImages, setPreviewImages] = useState([]);
  const [slug, setSlug] = useState();
  const [submit, setSubmit] = useState();
  const [price, setSPrice] = useState();
  const [message, setMessage] = useState();
  const navigation = useNavigate()



  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post(
        "http://localhost:4000/products/createProduct",
        {
          title,
          content,
          price,
          image,
          slug,
          category,
          message,
          previewImages,
          discount,
          inventory
        }
      );
      //   console.log(result.data.message)
      setMessage(result.data.message);
      window.location.href = "/shop/index";
      setSubmit(true);
    } catch (error) {
      console.log(error);
    }
  };
  const notify = () =>
    toast(message, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  return (
    <>
     {submit ? notify() : ''}  <ToastContainer />
      <h1 style={{ color: "white", textAlign: "center" }}><marquee behavior="smooth">Edit Product {title}</marquee></h1>
      <div className="signup-page">
        <div className="form-register">
          <form onSubmit={(e) => handleSubmit(e)} >
            <input
              type="text"
              value={title}
              name="title"
              className="sign-form"
              onChange={(e) => setTitle(e.target.value)}
              placeholder="title"
            />

            <br />

            <textarea
              name="content"
              id=""
              cols="63"
              rows="10"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            ></textarea>
            <br />
            <input
              type="text"
              value={category}
              name="category"
              className="sign-form"
              onChange={(e) => setCategory(e.target.value)}
              placeholder="category separate with (,) "
            />

            <br />
            <input
              type="text"
              value={inventory}
              name="inventory"
              className="sign-form"
              onChange={(e) => setInventory(e.target.value)}
              placeholder="inventory"
            

            />

            <br />
            <input
              type="text"
              value={image}
              name="image"
              className="sign-form"
              onChange={(e) => setImage(e.target.value)}
              placeholder="image link"
            />
            <input
              type="text"
              value={slug}
              name="slug"
              className="sign-form"
              onChange={(e) => setSlug(e.target.value)}
              placeholder="slug"
            />
            <input
              type="text"
              value={discount}
              name="discount"
              className="sign-form"
              onChange={(e) => setSlug(e.target.value)}
              placeholder="discount"
            />
            <input
              type="text"
              value={price}
              name="price"
              className="sign-form"
              onChange={(e) => setSlug(e.target.value)}
              placeholder="price"
            />
       <h1>image previews</h1>
       <input
              type="file"
              value={previewImages}
              name="previewImages"
              className="sign-form"
              onChange={(e) => setPreviewImages(e.target.value)}
              placeholder="previewImages"
              multiple
            />
            <br />
            <button
              className="submit"
              type="submit"
              onClick={(e) => handleSubmit(e)}
            >
              Save
            </button>

          </form>
        </div>
      </div>
    </>
  );
};

export default CreateProduct;
