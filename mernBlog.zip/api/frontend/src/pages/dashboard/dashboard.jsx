import React from 'react'
import Navbar from '../../components/dashboard/navbar'

const dashboard = () => {
  return (
    <>
    <Navbar />
    </>
  )
}

export default dashboard