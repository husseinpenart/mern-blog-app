import React, { useEffect, useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import Cookies from "universal-cookie";
const cookies = new Cookies();
const token = cookies.get("TOKEN");
const Create = () => {
  const [title, setTitle] = useState();
  const [content, setContent] = useState();
  const [category, setCategory] = useState();
  const [writer, setWriter] = useState();
  const [image, setImage] = useState();
  const [slug, setSlug] = useState();
  const [submit, setSubmit] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const configuration = {
      method: "get",
      url: "http://localhost:4000/admins/dashboard",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    axios(configuration)
      .then((result) => {
        const admin = result.data.isAdmin;
        if (admin == true) {
          setWriter(result.data.name);
          console.log(result.data.name)
          setMessage(result.data.message);
        } else {
          window.location.href = "/*";
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const result = await axios.post(
        "http://localhost:4000/blogs/createBlog",
        {
          title,
          content,
          writer,
          image,
          slug,
          category,
          message,
        }
      );
      //   console.log(result.data.message)
      setMessage(result.data.message);
      window.location.href = "/Content/createblog";
      setSubmit(true);
    } catch (error) {
      console.log(error);
    }
  };
  const notify = () =>
    toast(message, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  return (
    <>
      {submit ? notify() : ""} <ToastContainer />
      <h1 style={{ color: "white", textAlign: "center" }}>Create New Blog</h1>
      <div className="signup-page">
        <div className="form-register">
          <form onSubmit={(e) => handleSubmit(e)}>
            <input
              type="text"
              value={title}
              name="title"
              className="sign-form"
              onChange={(e) => setTitle(e.target.value)}
              placeholder="title"
            />

            <br />

            <textarea
              name="content"
              id=""
              cols="63"
              rows="10"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            ></textarea>
            <br />
            <input
              type="text"
              value={category}
              name="category"
              className="sign-form"
              onChange={(e) => setCategory(e.target.value)}
              placeholder="category separate with (,) "
            />

            <br />
            <input
              type="text"
              value={writer}
              name="writer"
              className="sign-form"
              onChange={(e) => setWriter(e.target.value)}
              placeholder="writer"
              contentEditable="false"
            />

            <br />
            <input
              type="text"
              value={image}
              name="image"
              className="sign-form"
              onChange={(e) => setImage(e.target.value)}
              placeholder="image link"
            />
            <input
              type="text"
              value={slug}
              name="image"
              className="sign-form"
              onChange={(e) => setSlug(e.target.value)}
              placeholder="slug"
            />

            <br />
            <button
              className="submit"
              type="submit"
              onClick={(e) => handleSubmit(e)}
            >
              Save
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default Create;
