import React, { useEffect, useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate, useParams } from "react-router-dom";

const Edit = () => {
  const [title, setTitle] = useState();
  const [content, setContent] = useState();
  const [category, setCategory] = useState();
  const [writer, setWriter] = useState();
  const [image, setImage] = useState();
  const [slug, setSlug] = useState();
  const [submit, setSubmit] = useState();
  const navigation = useNavigate()
  

  const {id} = useParams()
 useEffect(()=>{
    const getBlogs = async()=>{
        try {
            const res = await axios.get("http://localhost:4000/blogs/singlePost/" + id)
           setTitle(res.data.title)
           setContent(res.data.content)
           setCategory(res.data.category)
           setWriter(res.data.writer)
           setImage(res.data.image)
           setSlug(res.data.slug)
        
          

        } catch (error) {
            console.log(error)
        }
    }
    getBlogs()
 } , [])
const updateBlog = async(e)=>{
    e.preventDefault()
    try {
        await axios.post(`http://localhost:4000/blogs/edit/${id}` ,{
            title,
            content,
            category,
            writer,
            image,
            slug
        })
        navigation('/Content/createblog')
    } catch (error) {
        console.log(error)
    }
}
  const notify = () =>
    toast(message, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  return (
    <>
     {submit ? notify() : ''}  <ToastContainer />
      <h1 style={{ color: "white", textAlign: "center" }}>Create New Blog</h1>
      <div className="signup-page">
        <div className="form-register">
          <form onSubmit={(e) => updateBlog(e)}>
            <input
              type="text"
              value={title}
              name="title"
              className="sign-form"
              onChange={(e) => setTitle(e.target.value)}
              placeholder="title"
            />

            <br />

            <textarea
              name="content"
              id=""
              cols="63"
              rows="10"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            ></textarea>
            <br />
            <input
              type="text"
              value={category}
              name="category"
              className="sign-form"
              onChange={(e) => setCategory(e.target.value)}
              placeholder="category separate with (,) "
            />

            <br />
            <input
              type="text"
              value={writer}
              name="writer"
              className="sign-form"
              onChange={(e) => setWriter(e.target.value)}
              placeholder="writer"
              contentEditable="false"

            />

            <br />
            <input
              type="text"
              value={image}
              name="image"
              className="sign-form"
              onChange={(e) => setImage(e.target.value)}
              placeholder="image link"
            />
            <input
              type="text"
              value={slug}
              name="image"
              className="sign-form"
              onChange={(e) => setSlug(e.target.value)}
              placeholder="slug"
            />

            <br />
            <button
              className="submit"
              type="submit"
              onClick={(e) => updateBlog(e)}
            >
              Save
            </button>
            {/* <ToastContainer />
            {login ? (
              notify()
            ) : (
              <p style={{ color: "yellow" }}>
                have an Account ?
                <Link to="/signup" style={{ color: "white" }}>
                  {" "}
                  Register{" "}
                </Link>
              </p>
            )} */}
          </form>
        </div>
      </div>
    </>
  );
};

export default Edit;
