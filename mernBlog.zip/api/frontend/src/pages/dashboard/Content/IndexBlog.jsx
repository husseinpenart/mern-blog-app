import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BiSolidMessageSquareEdit } from "react-icons/bi";
import { AiFillDelete } from "react-icons/ai";
import TextTruncate from "react-text-truncate";

import moment from "moment";
import axios from "axios";
const CreateBlog = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    fetchApi();
  }, []);
  const fetchApi = async () => {
    const result = await axios.get("http://localhost:4000/blogs");
    setPosts(result.data);
  };

  const deleteBlog = async (id) => {
    try {
      confirm("Are You Sure want to delete this item");
      await axios.delete(`http://localhost:4000/blogs/delete/${id}`);
      fetchApi();
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <br />
      <br />
      <Link
        to="/Content/Create"
        style={{
          color: "white",
          background: "blue",
          width: 200,
          height: 45,
          padding: 5,
          textDecoration: "none",
          margin: "0 auto",
          display: "block",
          textAlign: "center",
        }}
      >
        Create Blog
      </Link>
      <br />
      <br />
      <br />
      <br />
      <br />
      <table className="table-row">
        <thead>
          <tr>
            <th>Title</th>
            <th>Content</th>
            <th>Writer</th>
            <th>Date</th>
            <th>Operation</th>
          </tr>
        </thead>
        <tbody>
          {posts.map((e, i) => {
            return (
              <tr key={i}>
                <td>{e.title}</td>
                <td>
                  <TextTruncate
                    line={1}
                    element="p"
                    truncateText=" … "
                    text={e.content}
                  
                  />
                </td>
                <td>{e.writer}</td>
                <td>{moment(e.createdAt).format("MMMM Do YYYY")}</td>
                <td>
                  <Link
                    to={`/Content/edit/${e._id}`}
                    style={{ color: "yellow" }}
                  >
                    <BiSolidMessageSquareEdit />
                  </Link>{" "}
                  ||{" "}
                  <button
                    style={{ color: "red", background: "none", border: "none" }}
                    onClick={() => deleteBlog(e._id)}
                  >
                    <AiFillDelete />{" "}
                  </button>{" "}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
};

export default CreateBlog;
