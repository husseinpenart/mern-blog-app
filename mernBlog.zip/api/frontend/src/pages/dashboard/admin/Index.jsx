import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BiSolidMessageSquareEdit } from "react-icons/bi";
import { AiFillDelete } from "react-icons/ai";
import TextTruncate from "react-text-truncate";

import moment from "moment";
import axios from "axios";
const UsersIndex = () => {
  const [admin, setAdmin] = useState([]);

  useEffect(() => {
    fetchApi();
  }, []);
  const fetchApi = async () => {
    const result = await axios.get("http://localhost:4000/admins");
    setAdmin(result.data);
  };

  const deleteBlog = async (id) => {
    try {
      confirm("Are You Sure want to delete this item");
      await axios.delete(`http://localhost:4000/admins/delete-admin/${id}`);
      fetchApi();
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      <br />
      <br />

      <table className="table-row">
        <thead>
          <tr>
            <th>name</th>
            <th>username</th>
            <th>email</th>
            <th>Date of registration</th>
            <th>Role</th>
            <th>Operation</th>
          </tr>
        </thead>
        <tbody>
          {admin.map((e, i) => {
            return (
              <tr key={i}>
                <td>{e.name}</td>
                <td>{e.username}</td>
                <td>
                  <TextTruncate
                    line={1}
                    element="p"
                    truncateText=" … "
                    text={e.email}
                  
                  />
                </td>
         
                <td>{moment(e.createdAt).format("MMMM Do YYYY")}</td>
                <td>{e.isAdmin == true ? 'Manager' :'user'}</td>
                <td>
        
                  <button
                    style={{ color: "red", background: "none", border: "none" }}
                    onClick={() => deleteBlog(e._id)}
                  >
                    <AiFillDelete />{" "}
                  </button>{" "}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
};

export default UsersIndex;
