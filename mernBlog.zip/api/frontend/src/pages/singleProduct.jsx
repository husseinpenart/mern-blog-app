import React, { useState, useEffect } from "react";
import axios from "axios";
import moment from "moment";
import { useLocation } from "react-router-dom";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
const SingleProduct = () => {
  const productID = useLocation().pathname.split("/")[2];
  const [product, setProduct] = useState();
  const [preview, setPreView] = useState([]);
  useEffect(() => {
    const fetchProduct = async () => {
      const result = await axios.get(
        "http://localhost:4000/products/singleProduct/" + productID
      );
      setProduct(result.data);
    };
    fetchProduct();
  }, []);
  useEffect(() => {
    const takePreViewImage = async () => {
      const pre = await axios.get(
        "http://localhost:4000/products/singleProduct/" + productID
      );
      setPreView(pre.data.previewImages);
      console.table(pre.data.previewImages);
    };
    takePreViewImage();
  }, []);
  return (
    <>
      <div className="post-container">
        {product ? (
          <div>
            <br />
            <br />
            <br />
            <img
              src={product.image}
              alt=""
              style={{
                margin: "0 auto",
                display: "block",
                borderRadius: 35,
                width: 700,
              }}
            />
            <br />
            <br />
            <h1 style={{ color: "white", textAlign: "center" }}>
              {product.title}
            </h1>
            <br />
            <br />
            <div
              style={{
                position: "relative",
                display: "flex",
                flexWrap: "wrap",
              }}
            >
              <p style={{ color: "white", textAlign: "center", padding: 10 }}>
                Category:{" "}
                <span
                  style={{ background: "blue", padding: 5, borderRadius: 10 }}
                >
                  {product.category}
                </span>
              </p>
              <p style={{ color: "white", textAlign: "center", padding: 10 }}>
                price:{" "}
                <span
                  style={{
                    background: "green",
                    borderRadius: 10,
                    padding: 3,
                  }}
                >
                  {product.price} $
                </span>
              </p>
              <p style={{ color: "white", textAlign: "center", padding: 10 }}>
                Date:{" "}
                <span
                  style={{
                    background: "#65c4ff",
                    padding: 5,
                    borderRadius: 10,
                  }}
                >
                  {moment(product.createdAt).format("MMMM Do YYYY")}
                </span>
              </p>
              <p style={{ color: "white", textAlign: "center", padding: 10 }}>
                Discount:{" "}
                <span
                  style={{
                    background: "#65c4ff",
                    padding: 5,
                    borderRadius: 10,
                  }}
                >
                  {product.discount}%
                </span>
              </p>
            </div>

            <br />
            <br />
            <p style={{ margin: "0 auto", display: "block", width: "50%" }}>
              <span style={{ color: "white", lineHeight: 3 }}>
                {product.content}
              </span>
            </p>
            <Carousel showIndicators={true} infiniteLoop={true} showThumbs={true} thumbWidth={300} >
           
          
            {preview.map((e , i)=>{
                return(
                    
                    <img src={e} style={{ width: 500 }} />
                 
                )
            })}
          </Carousel>
          </div>
        ) : null}
      </div>
    </>
  );
};
export default SingleProduct;
