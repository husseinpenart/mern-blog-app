import React, { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import Cookies from "universal-cookie";
const cookies = new Cookies();
import { ToastContainer, toast } from "react-toastify";

const Login = () => {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [role, setRole] = useState();
  const [login, setLogin] = useState(false);
  const [message, setMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const configuration = {
      method: "post",
      url: "http://localhost:4000/admins/loginAdmin",
      data: {
        email,
        password,
        role,
      },
    };
    axios(configuration)
      .then((result) => {
        cookies.set("TOKEN", result.data.token, {
          path: "/",
        });
        console.log(result.data)
        const adminResult = result.data.isAdmin;
        if (adminResult == true) {
          window.location.href = "/dashboard";
          setLogin(true);

        } else if(adminResult == false) {
          window.location.href = "/profile";
          setLogin(true);
        }else{
          window.location.href = "*";
          
        }
      })
      .catch((error) => {
       console.log(error)
      });
  };

  const notify = () =>
    toast("🦄 you Logged in  successfully", {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  return (
    <>
      <h1 style={{ textAlign: "center", color: "white" }}>Login</h1>
      <div className="signup-page">
        <div className="form-register">
          <form onSubmit={(e) => handleSubmit(e)}>
            <input
              type="email"
              value={email}
              name="email"
              className="sign-form"
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email"
            />
            <input
              type="password"
              value={password}
              name="password"
              className="sign-form"
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password"
            />
            <br />
            <button
              className="submit"
              type="submit"
              onClick={(e) => handleSubmit(e)}
            >
              Login
            </button>
            <ToastContainer />
            {login ? (
              notify()
            ) : (
              <p style={{ color: "yellow" }}>
                have an Account ?
                <Link to="/signup" style={{ color: "white" }}>
                  {" "}
                  Register{" "}
                </Link>
              </p>
            )}
          </form>
        </div>
      </div>
    </>
  );
};
export default Login;
