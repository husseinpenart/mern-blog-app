import axios from "axios";
import React , {useState , useEffect} from "react";
import moment from "moment";
import { Link } from "react-router-dom";
import TextTruncate from 'react-text-truncate';
// import api from './fetchApi.js'
const Blog = ()=>{
  const [blogs, setBlogs] = useState([]);
  useEffect(()=>{
    const fetchBlogs = async()=>{
     const results = await axios.get('http://localhost:4000/blogs')
     setBlogs(results.data)
    }
    fetchBlogs()
  }, [])
  // make blog content short 
  // const truncate = (str, n) => {
	// 	return str?.length > n ? str.substr(0, n - 2) + "..." : str;
	// };
    return (
   <>
   <div className="divider"></div>
   <h3 className="ourblogs">Our Blogs</h3>
   <div className="container">
   {
    blogs.map((blog,index)=>{
      return (
        <div className="card" key={index}>
        <div className="card__header">
          <img src={blog.image} alt="card__image" className="cardimg" width={600} />
        </div>
        <div className="card__body">
          <span className="tag tag-blue">{blog.category}</span>
          <h3><Link to={`singlePage/${blog._id}`}   className="titleblog">{blog.title}</Link></h3>
          <TextTruncate
    line={1}
    element="p"
    truncateText= " … "
    text={blog.content}
    textTruncateChild={<Link to={`singlePage/${blog._id}`} style={{color:'white' , textDecoration:'none' , background:'purple'}}>Read More</Link>}
/>
        </div>
        <div className="card__footer">
          <div className="user">
            <img src="https://i.pravatar.cc/40?img=1" alt="user__image" className="user__image" />
            <div className="user__info">
              <h5>{blog.writer}</h5>
              <small>{ moment(blog.createdAt).format('MMMM Do YYYY')}</small>
            </div>
          </div>
        </div>
      </div>
      )
    })
   }
 

</div>


   </>
    )
}
export default Blog


// import React, { useState, useEffect } from "react";
// import axios from "axios";

// const  Blog = ()=> {
// const [blogs , setBlogs] = useState([])
// // console.log(blogs)
// useEffect(()=>{
//   const FetchBlogs = async ()=>{
//     const result = await axios.get('http://localhost:4000/blogs')
//     setBlogs(result.data)

//   }
//   FetchBlogs()
// } ,[])

//   return (
// <>
// {
//   blogs.map((blog)=>{
//    return( <h3>{blog.title}</h3>)
//   })
// }

// </>
//   );
// }

// export default Blog;