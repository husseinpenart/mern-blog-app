import React, { useEffect, useState } from "react";
import axios from "axios";
import moment from "moment";
import { Link } from "react-router-dom";
import TextTruncate from 'react-text-truncate';
const Products = ()=>{
    const [product , setProducts] = useState([])

    useEffect(()=>{
        const fetchProducts = async()=>{
         const results = await axios.get('http://localhost:4000/products')
        setProducts(results.data)
        console.table(results.data)
        }
        fetchProducts()
    } ,[])

       
    return(
        <>
      <div className="divider"></div>
      <h3 className="ourblogs">Our Products</h3>
      <div className="container">
      {product.map((e,i)=>{
        return (
            <div className="card" key={i}>
            <div className="card__header">
              <img src={e.image} alt="card__image" className="cardimg" width={600} />
            </div>
            <div className="card__body">
              <span className="tag tag-blue">{e.category}</span>
              <h3><Link to={`singleProduct/${e._id}`}   className="titleblog">{e.title}</Link></h3>
              <p>  <TextTruncate
    line={1}
    element="p"
    truncateText= " … "
    text={e.content}
    textTruncateChild={<Link to={`singlePage/${e._id}`} style={{color:'white' , textDecoration:'none' , background:'purple'}}>See</Link>}
/></p>
            </div>
            <div className="card__footer">
              <div className="user">
              <h5>{e.price} $ </h5>     
                         <div className="user__info">
                 
                  <small>{ moment(e.createdAt).format('MMMM Do YYYY')}</small>
                </div>
              </div>
            </div>
          </div>
        )
      })}
      </div>
        </>
    )
}

export default Products