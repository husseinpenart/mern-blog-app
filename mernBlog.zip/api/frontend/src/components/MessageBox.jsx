import React, { useState } from "react";
import axios from "axios";

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const MessageBox = () => {
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("");
  const [message, setMessage] = useState("");
  const [successmessage , setSuccessMessage] = useState(false)
  const handleSubmit = (e) => {
    // prevent the form from refreshing the whole page
    e.preventDefault();

    // set configurations
    const configuration = {
      method: "post",
      url: "http://localhost:4000",
      data: {
        title,
        priority,
        message
      },
    };

    // make the API call
    axios(configuration)
      .then((result) => {
        setSuccessMessage(true);
      })
      .catch((error) => {
        error = new Error();
      });
  };

  const notify = () => toast('🦄 Message send successfully', {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "light",
    });;

  return (
    <>
 
      <form onSubmit={(e)=>handleSubmit(e)}>
        <div className="Forms">
          <input
            type="text"
            className="formInput"
            placeholder="title"
            value={title}
            name="title"
            onChange={(e)=> setTitle(e.target.value)}
          />
          <br />
          <select value={priority} type="text" className="formInput"
          onChange={(e)=> setPriority(e.target.value)}
          name="priority"
          >
            <option value="Very Hight">Very Hight</option>
            <option value="Hight">Hight</option>
            <option value="Medium">Medium</option>
            <option value="low">low</option>
          </select>
          <br />
          <textarea
            type="text"
            value={message}
            className="textinput"
            name="message"
            id=""
            cols="30"
            rows="10"
            placeholder="Your Message"
            onChange={(e)=> setMessage(e.target.value)}
          ></textarea>
          <br />
          <button className="submitMessage" type="submit"
          onClick={(e) => handleSubmit(e)} >Submit</button>
                <ToastContainer />
        </div>
      {successmessage ? notify() : ''}

      </form>
    </>
  );
};
export default MessageBox;
