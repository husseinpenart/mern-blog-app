import React from "react";
import moment from "moment";
const FormatDate = () => {
  return moment().format('MMMM Do YYYY');
};
export default FormatDate;
