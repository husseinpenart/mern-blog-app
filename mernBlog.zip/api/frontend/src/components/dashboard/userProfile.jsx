import React, { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "universal-cookie";
const cookies = new Cookies();
const token = cookies.get("TOKEN");

const Profile = () => {
  const [message, setMessage] = useState("");
  const [user, setUser] = useState("");
  useEffect(() => {
    const configuration = {
      method: "get",
      url: "http://localhost:4000/admins/dashboard",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    axios(configuration)
      .then((result) => {
        setUser(result.data.user);
        setMessage(result.data.message);
      })
      .catch((error) => {
        console.log(error)
      });
  }, []);

  // logout


  return (
    <>
      <br />
      <h3 style={{ color: "white" }}>
        <marquee behavior="smooth" direction="right">
          {message}
        </marquee>
      </h3>

      <br />
      <br />
      <div className="profile-card">
        <img
          src="https://img.freepik.com/premium-vector/account-icon-user-icon-vector-graphics_292645-552.jpg?w=2000"
          alt=""
          className="profile-img"
        />
        <p>
          Name: <span className="spanInfo">{user.name}</span>
        </p>
        <p>
          UserName: <span className="spanInfo">{user.username}</span>
        </p>
        <p>
          Email: <span className="spanInfo">{user.email}</span>
        </p>
        
      </div>
      <br />
      <button className="submit" type="submit" onClick={() => logout()}>
          Logout
        </button>
    </>
  );
};

export default Profile;
