import React, { useRef , useEffect } from 'react'
import {AiOutlineMenu  ,AiOutlineClose} from 'react-icons/ai'
import { Link } from 'react-router-dom'
import Profile from './userProfile'

const Navbar = () => {
  const slide = React.useRef(false)
  const toggle = React.useRef(false)
  const close = React.useRef(false)
    const handleClick = ()=>{
      slide.current.style.display  = 'block'
      toggle.current.style.display  = 'none'
    }
    const closeClick = ()=>{
      close.current.style.display  = 'block'
      slide.current.style.display  = 'none'
      toggle.current.style.display  = 'block'

    }
    const logout = () => {
      // destroy the cookie
      cookies.remove("TOKEN", { path: "/" });
      // redirect user to the landing page
      window.location.href = "/login";
    };
  return (
    <>
<div style={{float:'right'}}>    <Profile /></div>
    <button className='toggle-menu' onClick={handleClick} ref={toggle}><AiOutlineMenu  /></button>
     <div className='slide-container' ref={slide}>
     <button className='close-menu' onClick={closeClick} ref={close}><AiOutlineClose  /></button>

        <ul>
            <li><a href=""><Link to="/shop/index">Product</Link></a></li>
            <li><a href=""><Link to="/Content/createblog">Blog</Link></a></li>
            <li><a href=""><Link to="/admin/index">userList</Link></a></li>
        </ul>
      <p className='developer'>Developer   <a style={{color:'red'}} href="https://www.linkedin.com/in/hussain-asadi-1157221b9/">Hussein Asadi</a></p>
     </div>
    </>
  )
}

export default Navbar