import React from "react";
import { Link } from "react-router-dom";
const NavBar = () => {
  return (
    <>
      <div className="navBackground">
        <nav className="navbar">
          <ul className="ul-nav">
            <li>
              <a href="">Home</a>
            </li>
            <li>
              <a href="">Blog</a>
            </li>
            <li>
              <a href="">Contact</a>
            </li>
            <li>
              <a href="">Product</a>
            </li>
            <li>
              <a href="">About</a>
            </li>
            <li className="signup-login">
               
                <Link to="/signup">signup</Link>
            </li>
            <li className="signup-login">
            <Link to="/login">Login</Link>
            </li>
          </ul>
        </nav>
      </div>

    </>
  );
};
export default NavBar;
