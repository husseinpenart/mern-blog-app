import React from "react";
import { motion } from "framer-motion"
import programmer from '../assets/image/programming.png'
import MessageBox from "./MessageBox";

const Hero = ()=>{
    return(
        <>
        <div className="hero-section">
        <motion.img
       initial={{ y: -10 }}
       
       animate={{
        scale: [1, 1, 1, 1, 1],
        rotate: [0, 0, 100, 50, 0],
        borderRadius: ["20%", "20%", "50%", "50%", "20%"],
        y: 10 
      }}
       transition={{
         type: "smooth",
         repeatType: "mirror",
         duration: 5,
         repeat: Infinity,
       }}
       src={programmer}
       alt="floater"
       className="heroimg"
       
    />
    <h1 className="title">Welcome To MY Mern Blog</h1>
    <br />
    <p className="undertitle">This is fre project you can Use for Your Personal Projects</p>
    <br />
      <MessageBox />
        </div>
        </>
    )
}
export default Hero