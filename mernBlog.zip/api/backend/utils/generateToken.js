const jwt = require("jsonwebtoken");

const generateToken = (id) => {
  return jwt.sign({ id }, "213890wfhuwhfehJIEJFWOF", {
    expiresIn: "24h",
  });
};

module.exports = generateToken;
