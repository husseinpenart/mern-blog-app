const mongoose = require('mongoose')

const contact = new mongoose.Schema({
    title:String,
    priority:String,
    message:String,
    createdAt:{type:Date , default:Date.now()},

})

const contactForm = mongoose.model('contactForm' , contact)
module.exports = contactForm