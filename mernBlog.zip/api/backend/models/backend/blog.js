const mongoose = require('mongoose')
const blog = new mongoose.Schema({
     title:String,
     image:String,
     slug:String,
     content: String,
     category:String,
     writer:String,
     createdAt:{type:Date , default:Date.now()},
     updatedAt:{type:Date , default:Date.now()}
})

const Blog = mongoose.model('Blog' , blog)
module.exports = Blog