const mongoose = require('mongoose')
const products = new mongoose.Schema({
    title:String,
    Slug:String,
    image:String,
    previewImages:{type:[Object], default: []},
    content:String,
    inventory:String,
    category:String,
    price:Number,
    discount:Number,
    createAt:{type:Date , default:Date.now()}

})
const Products = mongoose.model('Products' , products)
module.exports = Products