const mongoose = require("mongoose");
const bcrypt = require('bcryptjs')

const admin = new mongoose.Schema({
  name: String,
  username: String,
  email: {
    type: String,
    required: [true, "Please provide an Email!"],
    unique: [true, "Email Exist"],
  },
  password: {
    type: String,
    required: [true, "Please provide a password!"],
    unique: false,
  },
  profile: String,
  createdAt: Date,
  token: String,
  isAdmin: {
    type: Boolean,
    required: true,
    default: false,
  },
});
admin.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password)
}

admin.pre('save', async function (next) {
  if (!this.isModified('password')) {
    next()
  }

  const salt = await bcrypt.genSalt(10)
  this.password = await bcrypt.hash(this.password, salt)
})

const Admin = mongoose.model("Admin", admin);
module.exports = Admin;
