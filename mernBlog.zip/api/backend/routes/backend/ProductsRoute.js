const {Router} = require('express')
const  ProductController  = require('../../controllers/backend/ProductsControllers')
const router = new Router()


router.get('/' , ProductController.getProduct )
router.post('/createProduct' , ProductController.createProducts)
router.get('/singleProduct/:id' , ProductController.getSingleProducts)
router.post('/editProduct/:id' , ProductController.editProducts)
router.delete('/deleteProduct/:id' , ProductController.deleteProducts)

module.exports = router