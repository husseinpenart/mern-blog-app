const {Router} = require('express')
const BlogControllers = require('../../controllers/backend/blogController')
const router = new Router()

router.get('/' , BlogControllers.getBlogs)
router.post('/createBlog' , BlogControllers.addBlog)
router.get('/singlePost/:id' , BlogControllers.singlePost)
router.post('/edit/:id' , BlogControllers.editBlog)
router.delete('/delete/:id' , BlogControllers.deleteBlog)


module.exports = router