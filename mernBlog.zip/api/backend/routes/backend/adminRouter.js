const {Router} = require('express')
const AdminControllers = require('../../controllers/backend/adminControllers')
const {admin, userAuth}= require('../../utils/Auth')
const router = new Router()
 router.get('/' ,  AdminControllers.getAdmins)
 router.post('/createAdmin' ,  AdminControllers.createAdmin)
 router.post('/loginAdmin' ,  AdminControllers.loginAdmin)
 router.get("/profile",userAuth , AdminControllers.authEndpoint);
 router.get("/dashboard", userAuth , AdminControllers.authDashboard);
 router.delete("/delete-admin/:id", admin , AdminControllers.deleteAdmin);
  


module.exports = router