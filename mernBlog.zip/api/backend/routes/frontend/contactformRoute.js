const {Router} = require('express')
const router = new Router()
const Home = require('../../controllers/Frontend/Home')

router.get('/' , Home.HomeRoute)
router.post('/' , Home.contactRoute)
router.get('/messages' , Home.getMessages)
router.delete('/messages/:id' , Home.deleteMessage)
router.get('/messages/:id' , Home.singleMessage)

module.exports = router