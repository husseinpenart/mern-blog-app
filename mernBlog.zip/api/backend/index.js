const express = require("express");
const cors = require("cors");
const cookieSession = require("cookie-session");
require("dotenv").config();
const chalk = require("chalk");
const cookieParser = require("cookie-parser");

const connectDB = require("./connection/database");
const app = express();
connectDB();
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content, Accept, Content-Type, Authorization"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, PATCH, OPTIONS"
  );
  next();
});
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(cookieParser());
app.use("/", require("./routes/frontend/contactformRoute"));
app.use("/blogs", require("./routes/backend/blogRoutes"));
app.use("/products", require("./routes/backend/ProductsRoute"));
app.use("/admins", require("./routes/backend/adminRouter"));
const port = process.env.PORT || 4000;

app.listen(
  port,
  console.log(chalk.bgCyan(`app is listening on ${chalk.magenta(port)}`))
);
