const Admin = require("../../models/backend/admin");
const generateToken = require("../../utils/generateToken");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
exports.getAdmins = async (req, res) => {
  try{
    const admin = await Admin.find({}).sort({createdAt:"desc"});
    if(!admin){
      res.json({
        status:401,
        message:'no user found'
      })
    }else{

      res.json(admin)
    }
}
catch(error){
    res.status(500).json({message: error.message})
}
};
exports.createAdmin = async (req, res) => {
  // try {
  //   const { name, username, password, profile, email } = req.body;

  //   if (
  //     name == "" ||
  //     username == "" ||
  //     password == "" ||
  //     email == "" ||
  //     password == ""
  //   ) {
  //     res.send({
  //       status: 416,
  //       success: false,
  //       message: "please fill the requested fields",
  //     });
  //   } else {
  //     bcrypt
  //       .hash(req.body.password, 10)
  //       .then(async (hashedPassword) => {
  //         const adminCreated = new Admin({
  //           name: req.body.name,
  //           username: req.body.username,
  //           password: hashedPassword,
  //           profile: req.body.profile,
  //           email: req.body.email,
  //         });
  //         if (adminCreated.email) {
  //           res.send({
  //             status: 404,
  //             success: false,
  //             message: `admin with email of : "${adminCreated.email}" already exist`,
  //           });
  //         }
  //         await adminCreated
  //           .save()
  //           .then((result) => {
  //             res.send({
  //               status: 200,
  //               success: true,
  //               message: `admin with name of : "${adminCreated.name}" created successFully`,
  //               adminCreated,
  //             });
  //           })
  //           .catch((error) => {
  //             res.status(500).send({
  //               message: "Error creating user",
  //               error,
  //             });
  //           });
  //       })
  //       .catch((e) => {
  //         res.status(500).send({
  //           message: "Password was not hashed successfully",
  //           e,
  //         });
  //       });
  //   }
  // } catch (error) {
  //   console.log(error);
  // }

  const { name, email, username, password } = req.body;

  const userExists = await Admin.findOne({ email });

  if (userExists) {
    res.status(400);
    throw new Error("User already exists");
  }

  const user = await Admin.create({
    name,
    email,
    password,
    username,
  });

  if (user) {
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      token: generateToken(user._id),
      username: user.username,
    });
  } else {
    res.status(400);
    throw new Error("Invalid user data");
  }
};
exports.loginAdmin = async (req, res) => {
  // // check if email exists
  // Admin.findOne({ email: req.body.email })
  //   // if email exists
  //   .then((user) => {
  //     // compare the password entered and the hashed password found
  //     bcrypt
  //       .compare(req.body.password, user.password)

  //       // if the passwords match
  //       .then((passwordCheck) => {
  //         // check if password matches
  //         if (!passwordCheck) {
  //           return res.status(400).send({
  //             message: "Passwords does not match",
  //             error,
  //           });
  //         }

  //         //   create JWT token
  //         const token = jwt.sign(
  //           {
  //             userId: user._id,
  //             userEmail: user.email,
  //           },
  //           "RANDOM-TOKEN",
  //           { expiresIn: "24h" }
  //         );

  //         //   return success response
  //         res.status(200).send({
  //           message: "Login Successful",
  //           email: user.email,
  //           token,
  //         });
  //       })
  //       // catch error if password does not match
  //       .catch((error) => {
  //         res.status(400).send({
  //           message: "Passwords does not match",
  //           error,
  //         });
  //       });
  //   })
  //   // catch error if email does not exist
  //   .catch((e) => {
  //     res.status(404).send({
  //       message: "Email not found",
  //       e,
  //     });
  //   });

  const { email, password } = req.body;

  const user = await Admin.findOne({ email });

  if (user && (await user.matchPassword(password))) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      username: user.username,
      token: generateToken(user._id),
    });
  } else {
    res.status(401).json({
      message:"Invalid email or password"
    });
  
  }
};
exports.authEndpoint = async (req, res, next) => {
  const user = await Admin.findById(req.user.id);

  if (user) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      message: `Welcome User with username of ${user.username}  `,
      user,
    });
  } else {
    res.status(404).json({
      message: `User with ${user.email} not Found`,
    });
  }
};

exports.authDashboard = async (req, res, next) => {
  const user = await Admin.findById(req.user.id);
   console.log(user.isAdmin)
  if (user.isAdmin == true) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      message: `Welcome User with username of ${user.username}  `,
      user,
    });
  } else {
    res.status(404).json({
      message: `User with ${user.email} not Found`,
    });
  }
};
exports.deleteAdmin = async (req, res) => {
  try {
    const DeleteAdmin = await Admin.findByIdAndDelete(req.params.id);
    if (!DeleteAdmin) {
      res.send({
        status: 204,
        success: false,
        message: "user by requested id not found",
      });
    } else {
      res.send(`admin by name of ${DeleteAdmin.name} deleted successfully `);
    }
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};
