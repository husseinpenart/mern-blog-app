const Blog = require("../../models/backend/blog");

exports.getBlogs = async (req, res) => {
  try{
    const data = await Blog.find({}).sort({createdAt:"desc"});
    res.json(data)
}
catch(error){
    res.status(500).json({message: error.message})
}

 
  
};

exports.addBlog = async (req, res, next) => {
 try {
  const { title, image, slug, content, category, writer } = req.body;
  if (title == "" || slug == "") {
    res.json({
      status: 400,
      success: false,
      message: `please fill the ${title} , ${slug}`,
    });
  } else {
    const blogData = new Blog({
      title,
      image,
      slug,
      content,
      category,
      writer,
    });
    await blogData.save();
    res.json({
      status: 200,
      success: true,
      blogData,
      message: `your blog created Successful by title of ${blogData.title}`,
    });
  }
 } catch (error) {
  next(error)
 }
  
};
exports.singlePost = async(req,res,next)=>{
  try{
    const single = await Blog.findById(req.params.id);
    res.json(single)
}
catch(error){
    res.status(500).json({message: error.message})
}
}
exports.editBlog = async(req,res)=>{
    try {
      const id = req.params.id
      const updateBlog = req.body
      const result = await Blog.findByIdAndUpdate(id , updateBlog )
      res.json(result)
    } catch (error) {
      res.status(404).json({message:error.message})

    }
}
exports.deleteBlog = async(req,res)=>{
    
try {
  const Deleteblog = await Blog.findByIdAndDelete(req.params.id)
  res.send(`blog by title of ${Deleteblog.title} deleted successfully `);

} catch (error) {
  res.status(404).json({message:error.message})

} 
}
