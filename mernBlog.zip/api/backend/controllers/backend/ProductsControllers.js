const Products = require("../../models/backend/products");
exports.getProduct = async (req, res, next) => {
  try {
    const product = await Products.find({}).sort({ createdAt: "desc" });
    if (product.length == 0) {
      res.send({
        status: 302,
        message: "unfortunately there is no products",
        success: false,
      });
    } else {
     res.status(200).json(product);
    }
  } catch (error) {
    console.log(error);
  }
};
exports.createProducts = async (req, res) => {
  try {
    const { title, Slug, image, previewImages, content, inventory, category, price,discount } =
      req.body;
    if (title == "" || Slug == "") {
      res.send({
        status: 403,
        success: false,
        message: `please fill the requested methods `,
      });
    } else {
      const createproducts = new Products({
        title,
        Slug,
        image,
        previewImages,
        content,
        inventory,
        category,
        price,
        discount
      });
      await createproducts.save()
        

      res.json({
        status: 200,
        success: true,
        message: `product ${createproducts.title} created Successfully`,
        createproducts,
      });
    }
  } catch (error) {
    console.log(error);
  }
};
exports.getSingleProducts = async (req, res) => {
  try {
    const single = await Products.findById(req.params.id);
    res.json(single)
    
  } catch (error) {
    console.log(error);
  }
};
exports.editProducts = async (req, res) => {
  try {
    const id = req.params.id;
    const updateProducts = req.body;
    const editproduct = await Products.findByIdAndUpdate(id, updateProducts);
    if (!editproduct) {
      res.send({
        status: 404,
        message: "product not found",
        success: false,
      });
    } else {
      res.send({
        status: 200,
        success: true,
        message: `product with id : ${editproduct._id} updated successfully`,
        editproduct,
      });
    }
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};

exports.deleteProducts = async (req, res) => {
  try {
    const deletePro = await Products.findByIdAndDelete(req.params.id);
    if (!deletePro) {
      res.send({
        status: 404,
        message: "product not found",
        success: false,
      });
    } else {
      res.send({
        status: 201,
        success: true,
        message: `product with title of "${deletePro.title}" deleted successfully`,
        deletePro,
      });
    }
  } catch (error) {
    res.status(404).json({ message: error.message });
  }
};
