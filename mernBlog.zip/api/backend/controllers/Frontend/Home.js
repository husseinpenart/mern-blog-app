const ContactForm = require("../../models/frontend/forms");
exports.HomeRoute = async (req, res) => {
  try {
    res.status(200).json("Welcome to Home Page");
  } catch (error) {
    console.log(
      chalk.red(`you get an error in home page by message of ${error} `)
    );
  }
};
exports.getMessages = async (req, res) => {
  const messagesFromContact = await ContactForm.find({});
  if (messagesFromContact.length == 0) {
    res.status(400).send("No message found");
  } else {
    res.send({
      status: 201,
      success: true,
      message: "Messages Found Successfully",
      messagesFromContact,
    });
  }
};
exports.contactRoute = async (req, res, next) => {
  try {
    const { title, priority, message } = req.body;
    if (title == "") {
      return res.status(422).send({
        error: true,
        message: "form is not true",
      });
    }
    const contact = new ContactForm({
      title,
      priority,
      message,
    });
    await contact.save();
    res.status(201).send({
      success: true,
      status: 200,
      message: "new message add successfully",
      contact,
    });
  } catch (error) {
    next(error);
  }
};
exports.singleMessage = async(req,res)=>{
    try {
        const message = await ContactForm.findById(req.params.id)
        if(message.length == 0){
            res.status(404).send({
                success:false,
                message:`no message by the ${message.id} which you requested found in database`
            })
        }else{
            res.send({
                status:200,
                success:true,
                message
            })
        }
    } catch (error) {
        res.status(404).json({message:error.message})
    }
}




exports.deleteMessage = async (req, res) => {
  try {
    const id = req.params.id;
    const contactform = await ContactForm.findByIdAndDelete(id);
    res.send(`message by title of ${contactform.title} deleted successfully `);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};


